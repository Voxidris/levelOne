package Items;

import characters.CombativeCharacter;

public interface IConsumables {
	
	public abstract void useItem(CombativeCharacter c);

}
