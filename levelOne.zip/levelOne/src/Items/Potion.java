package Items;

import back.Entity;
import characters.CombativeCharacter;

public class Potion extends Item implements IConsumables {
	private int type;
	private int boostValue;
	private int duration;

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public int getBoostValue() {
		return boostValue;
	}

	public void setBoostValue(int boostValue) {
		this.boostValue = boostValue;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}
	public void DecreaseDuration() {
		this.duration = duration--;
	}

	public final static int HEAL_POTION = 1;
	public final static int ATTACK_POTION = 2;
	public final static int DEFENSE_POTION = 3;
	public final static int SPEED_POTION = 4;

	@Override
	public void useItem(CombativeCharacter c) {
		c.setCurrentPotion(this);
		if (type == HEAL_POTION) {
			c.setCurrentHp(Math.min(getBoostValue() + c.getCurrentHp(), c.getMaxHp()));
		} else if (type == ATTACK_POTION)
			c.setAttack(c.getAttack() + boostValue);
		else if (type == DEFENSE_POTION)
			c.setDefense(c.getDefense() + boostValue);
		else if (type == SPEED_POTION)
			c.setSpeed(c.getSpeed() + boostValue);

		c.getInventory().dropItem(this);
	}

	public Potion(String name, String sprite, float value, String description, int type, int boostValue, int duration) {
		super(name, sprite, value, description);
		this.type = type;
		this.boostValue = boostValue;
		this.duration = duration;
	}

	public Potion(Potion other) {
		super(other.getName(), other.getSpritePath(), other.getValue(), other.getDescription());
		this.type = other.type;
		this.boostValue = other.boostValue;
	}

	public static Potion SMALL_POTION = new Potion("Croissant", "file:images/items/croissant.png", 5, "Restore 20HP", 1,
			20,1);
	public static Potion BIG_POTION = new Potion("Baguette", "file:images/items/baguette.png", 10, "Restore 50 HP", 1,
			50,1);

	@Override
	public Entity copieProfonde() {
		return new Potion(this);
	}

}
