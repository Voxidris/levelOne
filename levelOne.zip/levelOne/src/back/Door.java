package back;

public class Door {
	private Point location;
	private int idKey ;
	public Point getLocation() {
		return location;
	}
	public void setLocation(Point location) {
		this.location = location;
	}
	public int getIdKey() {
		return idKey;
	}
	public void setIdKey(int idKey) {
		this.idKey = idKey;
	}
	
}
